#!/usr/bin/env python3
"""
方法 08 — Crawl4AI（面向 LLM 的抓取）

算法：
  1. 底层仍是 Playwright 起一个真实浏览器（所以能执行 JS）
  2. 渲染完成后，把 DOM 清洗成干净的 Markdown —— 去掉导航、脚本、样式、广告
  3. 可选：挂 CSS/XPath 抽取策略做结构化输出，或挂 LLM 策略让模型抽

它解决的问题不是「能不能抓到」，而是「抓到的东西能不能直接喂给大模型」。
原始 HTML 一页可能几万 token，清洗成 Markdown 后往往只剩几百。
做 RAG、做文档问答时这个差距直接等于成本差距。

但注意：如果你的目标是**结构化数据**（像 13F 持仓表），
那么 CSS 选择器一步到位，转 Markdown 反而是绕远路 —— 还要再解析一次。
Crawl4AI 的主场是「非结构化正文」，不是「规整表格」。
"""
import sys, os, time, asyncio, re
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from common import TARGET_LOCAL, save

HERE = os.path.dirname(os.path.abspath(__file__))
COLS = ["rank", "ticker", "company", "pct", "activity", "shares", "value",
        "current_price", "w52_high", "w52_low"]


async def run():
    from crawl4ai import AsyncWebCrawler
    from crawl4ai.extraction_strategy import JsonCssExtractionStrategy
    import json as _json

    # 结构化抽取 schema —— Crawl4AI 不只会出 Markdown
    schema = {
        "name": "holdings",
        "baseSelector": "#holdings tbody tr",
        "fields": [
            {"name": "rank", "selector": "td:nth-child(1)", "type": "text"},
            {"name": "ticker", "selector": "td:nth-child(2)", "type": "text"},
            {"name": "company", "selector": "td:nth-child(3)", "type": "text"},
            {"name": "pct", "selector": "td:nth-child(4)", "type": "text"},
            {"name": "activity", "selector": "td:nth-child(5)", "type": "text"},
            {"name": "shares", "selector": "td:nth-child(6)", "type": "text"},
            {"name": "value", "selector": "td:nth-child(7)", "type": "text"},
            {"name": "current_price", "selector": "td:nth-child(8)", "type": "text"},
            {"name": "w52_high", "selector": "td:nth-child(9)", "type": "text"},
            {"name": "w52_low", "selector": "td:nth-child(10)", "type": "text"},
        ],
    }

    # Crawl4AI 0.9 起，运行参数集中到 CrawlerRunConfig（0.4 之前是直接传给 arun）
    from crawl4ai import CrawlerRunConfig, CacheMode
    cfg = CrawlerRunConfig(
        extraction_strategy=JsonCssExtractionStrategy(schema),
        wait_for="css:body[data-hydrated='true']",
        cache_mode=CacheMode.BYPASS,
    )
    async with AsyncWebCrawler(verbose=False) as crawler:
        res = await crawler.arun(url=TARGET_LOCAL, config=cfg)

    md = ""
    try:
        md = res.markdown.raw_markdown if hasattr(res.markdown, "raw_markdown") \
             else str(res.markdown)
    except Exception:
        md = ""

    rows = []
    if getattr(res, "extracted_content", None):
        try:
            rows = _json.loads(res.extracted_content)
        except Exception:
            rows = []
    return rows, md


def main():
    t0 = time.time()
    try:
        rows, md = asyncio.run(run())
    except Exception as e:
        save(HERE, [], elapsed=time.time() - t0,
             notes=f"运行失败：{type(e).__name__}: {str(e)[:150]}")
        return

    out = os.path.join(HERE, "output")
    os.makedirs(out, exist_ok=True)
    with open(os.path.join(out, "page.md"), "w", encoding="utf-8") as f:
        f.write(md)

    save(HERE, rows, elapsed=time.time() - t0,
         extra={"markdown_chars": len(md), "also_wrote": "output/page.md"},
         notes="JsonCssExtractionStrategy 做结构化抽取 + 同时产出干净 Markdown；底层是 Playwright 所以能看到 JS 列")


if __name__ == "__main__":
    main()
