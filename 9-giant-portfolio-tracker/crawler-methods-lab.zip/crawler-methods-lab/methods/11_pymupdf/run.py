#!/usr/bin/env python3
"""
方法 11 — PyMuPDF（PDF 解析，顺带演示表格抽取）

算法：
  1. 先用 PyMuPDF 生成一份「13F 季报 PDF」当素材（真实场景里这一步是下载来的）
  2. 打开 PDF，逐页调用 page.find_tables() 做表格检测
  3. 命中的表格用 table.extract() 取成二维数组
  4. 退路：page.get_text() 拿纯文本再自己切

定位：PDF 是**没有结构的结构化数据**——看起来是表格，底层只是
一堆带坐标的文字块。所有 PDF 解析库做的事，本质都是
「根据坐标和线条推测哪些文字属于同一行同一列」。

PyMuPDF 的特点是**快**（C 底层）且**轻**（无额外依赖）。
Docling 表格识别更准但依赖 torch，装起来好几个 G。
选哪个取决于：你的 PDF 表格规不规整、量大不大、能不能接受重依赖。
"""
import sys, os, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

import pymupdf
from common import save

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "output")
COLS = ["rank", "ticker", "company", "pct", "activity", "shares", "value"]

DATA = [
    ("1", "AAPL", "Apple Inc", "22.04", "Unchanged", "227917808", "65950296000"),
    ("2", "BRK.B", "Berkshire Hathaway Inc", "13.11", "Add", "98400000", "39240000000"),
    ("3", "GOOGL", "Alphabet Inc Class A", "10.52", "Buy", "142300000", "31480000000"),
    ("4", "MSFT", "Microsoft Corp", "9.87", "Unchanged", "61200000", "29540000000"),
    ("5", "AMZN", "Amazon.com Inc", "8.43", "Reduce", "111500000", "25230000000"),
    ("6", "NVDA", "NVIDIA Corp", "7.15", "Add", "134800000", "21400000000"),
    ("7", "XOM", "Exxon Mobil Corp", "5.62", "Unchanged", "142000000", "16820000000"),
    ("8", "JPM", "JPMorgan Chase & Co", "4.98", "Buy", "61900000", "14900000000"),
    ("9", "KO", "Coca-Cola Co", "3.74", "Unchanged", "400000000", "11190000000"),
    ("10", "PFE", "Pfizer Inc", "2.31", "Sold Out", "0", "0"),
]
WIDTHS = [36, 58, 190, 62, 76, 92, 104]


def make_pdf(path):
    """造一份带真实表格线的 PDF —— find_tables 依赖线条来切分单元格。"""
    doc = pymupdf.open()
    page = doc.new_page(width=720, height=540)
    page.insert_text((40, 46), "Demo Fund Management LP - Form 13F Holdings",
                     fontsize=14, fontname="hebo")
    page.insert_text((40, 64), "Period: Q2 2026 | Filed: 2026-08-14 | CIK 0001999999",
                     fontsize=8.5)

    x0, y0, rh = 40, 86, 26
    header = ["Rank", "Ticker", "Company", "% Port", "Activity", "Shares", "Value ($)"]
    nrows = len(DATA) + 1
    total_w = sum(WIDTHS)

    for i, cells in enumerate([header] + [list(d) for d in DATA]):
        y = y0 + i * rh
        x = x0
        for w, txt in zip(WIDTHS, cells):
            page.draw_rect(pymupdf.Rect(x, y, x + w, y + rh),
                           color=(0.75, 0.75, 0.78), width=0.6)
            page.insert_text((x + 4, y + 17), str(txt), fontsize=8.5,
                             fontname="hebo" if i == 0 else "helv")
            x += w
    page.draw_rect(pymupdf.Rect(x0, y0, x0 + total_w, y0 + nrows * rh),
                   color=(0.3, 0.3, 0.35), width=1.1)

    doc.save(path)
    doc.close()


def main():
    t0 = time.time()
    os.makedirs(OUT, exist_ok=True)
    pdf_path = os.path.join(OUT, "demo_13f_report.pdf")
    make_pdf(pdf_path)

    doc = pymupdf.open(pdf_path)
    rows, n_tables = [], 0
    for page in doc:
        tabs = page.find_tables()
        n_tables += len(tabs.tables)
        for tab in tabs.tables:
            for rec in tab.extract():
                cells = [(c or "").strip() for c in rec]
                if not cells or not cells[0].isdigit():
                    continue
                cells += [""] * (len(COLS) - len(cells))
                rows.append(dict(zip(COLS, cells[:len(COLS)])))
    text = "\n".join(p.get_text() for p in doc)
    doc.close()

    with open(os.path.join(OUT, "extracted_text.txt"), "w", encoding="utf-8") as f:
        f.write(text)

    save(HERE, rows, elapsed=time.time() - t0,
         extra={"tables_detected": n_tables,
                "pdf": "output/demo_13f_report.pdf",
                "also_wrote": "output/extracted_text.txt"},
         notes="先造 PDF 再解析，演示完整往返；PDF 没有 JS 概念，故无 JS 列")


if __name__ == "__main__":
    main()
