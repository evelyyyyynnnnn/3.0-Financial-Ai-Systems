#!/usr/bin/env bash
# 方法 12 — curl / wget / aria2（命令行下载器）
#
# 算法：无解析，纯粹把字节搬下来。
#   curl   —— 单请求之王，几乎每台机器都有，适合写进脚本和 CI
#   wget   —— 带 --mirror 可以整站递归下载，断点续传好用
#   aria2c —— 多连接并行，单个大文件能切成 N 段同时下，批量下载最快
#
# 定位：当目标**已经是文件**（ZIP / CSV / PDF / XML）时，这一类就是全部答案。
# SEC 的 13F 季度数据集正是这种情况 —— 一个静态 ZIP 链接，
# 写个 curl + cron 就完事，上任何框架都是多余的。
#
# 关键区别：前面 01–09 解决的是「从 HTML 里抠数据」；
# 这一类解决的是「把文件搬下来」。搞清楚目标是哪一种，能省掉 90% 的工作。

set -u
HERE="$(cd "$(dirname "$0")" && pwd)"
OUT="$HERE/output"
mkdir -p "$OUT"
export NO_PROXY='*' no_proxy='*'

TARGET="${LAB_TARGET:-http://127.0.0.1:8899/fixture_13f.html}"
REMOTE="https://raw.githubusercontent.com/python/cpython/main/README.rst"

echo "{"                                        >  "$OUT/summary.json"
echo "  \"method\": \"12_cli_downloaders\","    >> "$OUT/summary.json"

# ---------- curl ----------
if command -v curl >/dev/null; then
  t=$(curl -sS -o "$OUT/via_curl.html" -w "%{time_total}" "$TARGET")
  sz=$(wc -c < "$OUT/via_curl.html" 2>/dev/null || echo 0)
  echo "  \"curl\": {\"ok\": true, \"bytes\": $sz, \"seconds\": \"$t\"}," >> "$OUT/summary.json"
  echo "curl   OK  ${sz}B"
else
  echo "  \"curl\": {\"ok\": false}," >> "$OUT/summary.json"; echo "curl   missing"
fi

# ---------- wget ----------
if command -v wget >/dev/null; then
  wget -q -O "$OUT/via_wget.html" "$TARGET" && ok=true || ok=false
  sz=$(wc -c < "$OUT/via_wget.html" 2>/dev/null || echo 0)
  echo "  \"wget\": {\"ok\": $ok, \"bytes\": $sz}," >> "$OUT/summary.json"
  echo "wget   OK  ${sz}B"
else
  echo "  \"wget\": {\"ok\": false}," >> "$OUT/summary.json"; echo "wget   missing"
fi

# ---------- aria2 ----------
if command -v aria2c >/dev/null; then
  aria2c -q -d "$OUT" -o via_aria2.html --allow-overwrite=true "$TARGET" && ok=true || ok=false
  sz=$(wc -c < "$OUT/via_aria2.html" 2>/dev/null || echo 0)
  echo "  \"aria2\": {\"ok\": $ok, \"bytes\": $sz}," >> "$OUT/summary.json"
  echo "aria2  OK  ${sz}B"
else
  echo "  \"aria2\": {\"ok\": false, \"reason\": \"未安装（apt 不可达）\"}," >> "$OUT/summary.json"
  echo "aria2  未安装"
fi

# ---------- 真实远程（证明不只是本地） ----------
code=$(curl -sS -o "$OUT/remote_real.txt" -w "%{http_code}" --max-time 25 "$REMOTE")
sz=$(wc -c < "$OUT/remote_real.txt" 2>/dev/null || echo 0)
echo "  \"remote_real_fetch\": {\"url\": \"$REMOTE\", \"http\": $code, \"bytes\": $sz}" >> "$OUT/summary.json"
echo "远程真实抓取 raw.githubusercontent -> HTTP $code, ${sz}B"

echo "}" >> "$OUT/summary.json"
echo "写出: $OUT/summary.json"
