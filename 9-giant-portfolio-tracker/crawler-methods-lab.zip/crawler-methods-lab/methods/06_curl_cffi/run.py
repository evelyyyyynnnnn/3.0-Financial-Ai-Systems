#!/usr/bin/env python3
"""
方法 06 — curl_cffi（TLS 指纹伪装）

算法：
  1. curl_cffi 底层用 curl-impersonate 编译的 libcurl
  2. impersonate="chrome" 让 TLS 握手的 JA3 指纹、HTTP/2 帧顺序、
     header 顺序全部和真实 Chrome 一致
  3. 之后的用法和 requests 完全一样

要解决的问题：Cloudflare、Akamai、PerimeterX 这类防护不只看 User-Agent，
它们看 **TLS 握手指纹**。Python 的 requests 用的是 OpenSSL 默认配置，
指纹和任何真实浏览器都不一样，一眼就被识别成脚本。

注意：这是「让请求看起来像浏览器」，不是「绕过登录或付费墙」。
对 SEC 这种无防护的站点完全没必要用；对 Dataroma 这种会返 403/429 的
二手站，它可能是你唯一能稳定拿到数据的办法 —— 但要先确认对方 ToS 允许。
"""
import sys, os, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from curl_cffi import requests as creq
from selectolax.lexbor import LexborHTMLParser as HTMLParser
from common import TARGET_LOCAL, save

HERE = os.path.dirname(os.path.abspath(__file__))
COLS = ["rank", "ticker", "company", "pct", "activity", "shares", "value",
        "current_price", "w52_high", "w52_low"]


def main():
    t0 = time.time()
    # impersonate 是这个库的全部意义所在
    r = creq.get(TARGET_LOCAL, impersonate="chrome", timeout=20)
    r.raise_for_status()

    tree = HTMLParser(r.text)
    rows = []
    for tr in tree.css("#holdings tbody tr"):
        tds = [td.text(strip=True) for td in tr.css("td")]
        row = dict(zip(COLS, tds))
        row["cusip"] = tr.attributes.get("data-cusip", "")
        rows.append(row)

    save(HERE, rows, raw=r.text, raw_ext="html", elapsed=time.time() - t0,
         extra={"impersonate": "chrome",
                "note_on_fingerprint": "真实价值在打有反爬的站点时，本地靶站体现不出来"},
         notes="结果与 01/02 相同；差异在网络层的 TLS 指纹，不在解析层")


if __name__ == "__main__":
    main()
