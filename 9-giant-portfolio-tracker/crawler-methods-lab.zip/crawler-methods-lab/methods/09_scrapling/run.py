#!/usr/bin/env python3
"""
方法 09 — Scrapling（自适应 selector）

算法：
  1. 第一次抓取时，除了按 selector 定位元素，还把该元素的**特征指纹**
     （标签名、属性集合、文本模式、在 DOM 中的相对位置、兄弟节点结构）存进本地库
  2. 下次页面改版、原 selector 失效时，用这份指纹在新 DOM 里做相似度匹配，
     自动找回「同一个」元素
  3. 需要 auto_save=True / auto_match=True 才启用这套机制

它解决的是爬虫工程里最烦的那件事：**目标站改版，selector 全挂，要重写。**
对长期运行的采集任务（比如你那个季度刷新的 13F 站），这个能力有实际价值。

代价：指纹匹配不是百分百可靠，改版幅度大时仍会错配，而且是**静默错配**——
拿到的是结构相似但语义不同的元素。所以必须配断言：
行数对不对、首行值对不对、字段格式对不对，不对就告警而不是继续跑。
"""
import sys, os, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from common import TARGET_LOCAL, save

HERE = os.path.dirname(os.path.abspath(__file__))
COLS = ["rank", "ticker", "company", "pct", "activity", "shares", "value",
        "current_price", "w52_high", "w52_low"]


def main():
    t0 = time.time()
    rows, engine = [], ""
    try:
        try:                              # 0.3+ 的接口
            from scrapling.fetchers import Fetcher
        except ImportError:               # 旧版回退
            from scrapling import Fetcher

        page = Fetcher.get(TARGET_LOCAL, stealthy_headers=True)
        engine = "scrapling.Fetcher (静态，不执行 JS)"

        for tr in page.css("#holdings tbody tr"):
            tds = [td.text.strip() for td in tr.css("td")]
            tds += [""] * (len(COLS) - len(tds))
            row = dict(zip(COLS, tds))
            row["cusip"] = tr.attrib.get("data-cusip", "")
            rows.append(row)

    except Exception as e:
        save(HERE, [], elapsed=time.time() - t0,
             notes=f"运行失败：{type(e).__name__}: {str(e)[:150]}")
        return

    save(HERE, rows, elapsed=time.time() - t0,
         extra={"engine": engine,
                "adaptive_note": "auto_save/auto_match 需多次运行跨版本才看得出效果，单次 demo 体现不了"},
         notes="静态 Fetcher 模式，结果同 01/02；自适应能力要在页面改版后才显现")


if __name__ == "__main__":
    main()
