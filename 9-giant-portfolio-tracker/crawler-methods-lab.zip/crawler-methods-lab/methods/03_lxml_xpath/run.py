#!/usr/bin/env python3
"""
方法 03 — lxml + XPath（精确定位）

算法：
  1. 任意 HTTP 客户端取回 HTML
  2. lxml.html.fromstring 建 DOM
  3. 用 XPath 表达式直接定位节点

XPath 相比 CSS 选择器的优势：能按文本内容选、能往上找父节点、
能写条件（例如「取 Activity 列等于 Buy 的那些行」）。
页面结构复杂、或者要按内容筛选时，XPath 比 CSS 省事得多。
"""
import sys, os, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

import requests
from lxml import html as lhtml
from common import TARGET_LOCAL, save

HERE = os.path.dirname(os.path.abspath(__file__))
COLS = ["rank", "ticker", "company", "pct", "activity", "shares", "value",
        "current_price", "w52_high", "w52_low"]


def main():
    t0 = time.time()
    r = requests.get(TARGET_LOCAL, timeout=20)
    r.raise_for_status()
    doc = lhtml.fromstring(r.text)

    rows = []
    for tr in doc.xpath('//table[@id="holdings"]/tbody/tr'):
        tds = [t.strip() for t in tr.xpath("./td//text()[normalize-space()]")]
        tds += [""] * (len(COLS) - len(tds))
        row = dict(zip(COLS, tds))
        row["cusip"] = tr.get("data-cusip", "")
        rows.append(row)

    # XPath 的看家本领：按内容筛选，CSS 做不到
    buys = doc.xpath('//table[@id="holdings"]/tbody/tr[td[5]="Buy"]/td[2]/text()')
    sold = doc.xpath('//table[@id="holdings"]/tbody/tr[td[5]="Sold Out"]/td[2]/text()')

    save(HERE, rows, raw=r.text, raw_ext="html", elapsed=time.time() - t0,
         extra={"xpath_filter_Buy": buys, "xpath_filter_SoldOut": sold},
         notes="演示了 XPath 按单元格内容筛选（Buy / Sold Out），这是 CSS 选择器做不到的")


if __name__ == "__main__":
    main()
