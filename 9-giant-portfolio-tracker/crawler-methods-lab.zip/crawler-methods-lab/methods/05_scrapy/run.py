#!/usr/bin/env python3
"""
方法 05 — Scrapy（爬虫框架）

算法：
  1. 定义一个 Spider 类，写 start_urls 和 parse() 回调
  2. Scrapy 引擎负责调度、并发、去重、重试、限速、中间件
  3. parse() 里用 response.css() / response.xpath() 抽数据，yield 出 item
  4. Item Pipeline 负责清洗和落盘

和前面几种「一次性脚本」的本质区别：Scrapy 是**框架**，它管的是
"几万个 URL 怎么排队、失败了怎么重试、并发多少不被封"这一层。
抓一页用它是杀鸡用牛刀；抓一万页不用它就得自己把这套重写一遍。

本脚本用 CrawlerProcess 在单文件里跑，省去 scrapy startproject 的目录结构。
"""
import sys, os, time, json
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

import scrapy
from scrapy.crawler import CrawlerProcess
from common import TARGET_LOCAL, save

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "output")
os.makedirs(OUT, exist_ok=True)
COLS = ["rank", "ticker", "company", "pct", "activity", "shares", "value",
        "current_price", "w52_high", "w52_low"]


class HoldingsSpider(scrapy.Spider):
    name = "holdings"
    start_urls = [TARGET_LOCAL]
    custom_settings = {
        "LOG_LEVEL": "ERROR",
        "FEEDS": {os.path.join(OUT, "scrapy_items.jsonl"): {"format": "jsonlines",
                                                           "overwrite": True}},
        "DOWNLOAD_DELAY": 0.1,          # 礼貌限速
        "CONCURRENT_REQUESTS": 4,
        "ROBOTSTXT_OBEY": False,        # 本地靶站没有 robots.txt
        "USER_AGENT": "crawler-methods-lab/1.0 (educational)",
    }

    def parse(self, response):
        for tr in response.css("#holdings tbody tr"):
            tds = [t.strip() for t in tr.css("td::text").getall()]
            tds += [""] * (len(COLS) - len(tds))
            item = dict(zip(COLS, tds))
            item["cusip"] = tr.attrib.get("data-cusip", "")
            yield item


def main():
    t0 = time.time()
    jl = os.path.join(OUT, "scrapy_items.jsonl")
    if os.path.exists(jl):
        os.remove(jl)

    proc = CrawlerProcess(settings={"LOG_LEVEL": "ERROR"})
    proc.crawl(HoldingsSpider)
    proc.start()                                   # 阻塞直到爬完

    rows = []
    if os.path.exists(jl):
        with open(jl, encoding="utf-8") as f:
            rows = [json.loads(ln) for ln in f if ln.strip()]

    save(HERE, rows, elapsed=time.time() - t0,
         extra={"engine": "Scrapy " + scrapy.__version__,
                "feed": "output/scrapy_items.jsonl"},
         notes="框架自带调度/并发/重试/限速；单页场景下这些都用不上")


if __name__ == "__main__":
    main()
