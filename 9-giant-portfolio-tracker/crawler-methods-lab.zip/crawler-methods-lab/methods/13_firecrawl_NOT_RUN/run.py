#!/usr/bin/env python3
"""
方法 13 — Firecrawl（托管抓取 API）   ⚠ 本实验环境未执行

未执行原因：需要 FIRECRAWL_API_KEY，且云端按量计费。本实验不消耗你的额度。
            （Firecrawl 有自托管开源版，但要起 Docker + Redis + Playwright 集群，
             在这个容器里装不动。）

算法：
  1. 你把 URL POST 给 Firecrawl 的服务端
  2. 它在自己的基础设施上起浏览器、处理反爬、重试、代理轮换
  3. 返回清洗好的 Markdown / HTML / 结构化 JSON
  4. /crawl 可以递归整站，/map 只返回站点所有 URL

它卖的不是技术，是**省心**：代理池、验证码、浏览器集群、重试逻辑
全都不用你管。规模化抓取时这些运维成本往往比写 parser 高得多。

对 13F 场景的判断：**不值得。** SEC 是静态文件、无反爬，
用托管服务等于为你完全用不上的能力付费。
Firecrawl 的主场是「要抓几千个结构各异、有反爬的站点」。

怎么跑：
    pip install firecrawl-py
    export FIRECRAWL_API_KEY=fc-xxxx
    python3 run.py
"""
import os, sys, json, time

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))
HERE = os.path.dirname(os.path.abspath(__file__))

TARGET = os.environ.get("LAB_TARGET", "https://example.com")


def main():
    key = os.environ.get("FIRECRAWL_API_KEY")
    if not key:
        print("未设置 FIRECRAWL_API_KEY —— 跳过。这正是本方法在实验里标记为「未执行」的原因。")
        return

    from firecrawl import FirecrawlApp
    app = FirecrawlApp(api_key=key)

    t0 = time.time()
    # ① 单页抓取：返回清洗后的 markdown + html
    res = app.scrape_url(TARGET, params={"formats": ["markdown", "html"]})

    # ② 结构化抽取：给个 JSON schema，让它直接返回结构化数据
    schema = {
        "type": "object",
        "properties": {
            "holdings": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "ticker": {"type": "string"},
                        "company": {"type": "string"},
                        "pct": {"type": "number"},
                        "shares": {"type": "number"},
                    },
                },
            }
        },
    }
    structured = app.scrape_url(
        TARGET,
        params={"formats": ["extract"], "extract": {"schema": schema}},
    )

    out = os.path.join(HERE, "output")
    os.makedirs(out, exist_ok=True)
    with open(os.path.join(out, "result.json"), "w", encoding="utf-8") as f:
        json.dump({"scrape": res, "structured": structured,
                   "elapsed_s": round(time.time() - t0, 2)},
                  f, ensure_ascii=False, indent=2, default=str)
    print("已写出 output/result.json")


if __name__ == "__main__":
    main()
