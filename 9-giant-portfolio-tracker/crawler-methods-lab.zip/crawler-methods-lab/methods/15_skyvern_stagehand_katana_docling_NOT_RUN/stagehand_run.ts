/**
 * 方法 16 — Stagehand 示例（TypeScript）   ⚠ 本实验环境未执行
 *
 * 要点：确定的步骤用普通 Playwright 写死（快、稳、免费），
 *      只有不确定的那一步才调 AI 原语（慢、贵、但能应付变化）。
 *
 * 运行：
 *   npm install @browserbasehq/stagehand playwright zod
 *   export OPENAI_API_KEY=sk-xxx
 *   npx tsx stagehand_run.ts
 */
import { Stagehand } from "@browserbasehq/stagehand";
import { z } from "zod";

const Holding = z.object({
  ticker: z.string(),
  company: z.string(),
  pct: z.number(),
  shares: z.number(),
  currentPrice: z.number().nullable(),
});

async function main() {
  const sh = new Stagehand({
    env: "LOCAL",                 // 换成 "BROWSERBASE" 可跑在托管浏览器上
    modelName: "gpt-4o-mini",
    verbose: 1,
  });
  await sh.init();
  const page = sh.page;

  // —— 确定的部分：普通 Playwright，不花一分钱 ——
  await page.goto("http://127.0.0.1:8899/fixture_13f.html");
  await page.waitForSelector("body[data-hydrated='true']");

  // —— 不确定的部分：交给模型按 schema 抽 ——
  const result = await page.extract({
    instruction:
      "抽取持仓表的每一行。只读页面上实际显示的数值，不要推断或编造。",
    schema: z.object({ holdings: z.array(Holding) }),
  });

  console.log(JSON.stringify(result, null, 2));
  await sh.close();
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
