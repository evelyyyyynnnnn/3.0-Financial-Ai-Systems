# 方法 15–18：本实验环境未执行的其余四种

这四个各有各的拦路条件，统一放在这里，代码在同目录的对应文件中。

---

## 15. Skyvern（视觉优先的 Agent 浏览器）

**未执行原因**：需要 LLM API key；官方部署方式是 Docker Compose（Postgres + 后端 + 前端），容器内起不来。

**算法**：和 Browser Use 同赛道，但走**视觉路线**——截图丢给多模态模型，模型回「点屏幕上 (x, y)」或「在这个框里填 xxx」。另有一套工作流引擎管多步任务。

**和 Browser Use 的分工**：

| | 路线 | 强项 | 弱项 |
|---|---|---|---|
| Browser Use | DOM→文本 | 快、省 token、点击精确 | canvas / 重视觉界面抓瞎 |
| Skyvern | 截图→视觉 | 任何界面都能看懂，表单填写强 | 慢、贵、坐标点击易偏 |

**对 13F**：同样不适用，理由同 Browser Use。

**怎么跑**
```bash
git clone https://github.com/Skyvern-AI/skyvern && cd skyvern
cp .env.example .env     # 填 LLM key
docker compose up -d     # http://localhost:8080
```

---

## 16. Stagehand（可控的 Agent 浏览器，Browserbase 出品）

**未执行原因**：TypeScript/Node 生态 + 需要 LLM key；本实验是 Python 环境。

**算法**：在 Playwright 之上加三个 AI 原语，其余照常写代码——
- `page.act("点登录按钮")` —— 让模型决定怎么点
- `page.extract({schema})` —— 让模型按 schema 抽数据
- `page.observe()` —— 问模型页面上有什么可操作的

**定位**：介于「纯代码」和「纯 agent」之间。确定的步骤你自己写死（快且稳），不确定的那一两步交给模型。这是三个 agent 方案里工程上最务实的一个。

**对 13F**：仍不需要，但如果将来要抓的是**有登录 + 结构多变**的二手站，Stagehand 比全自动 agent 更可控。

**怎么跑**
```bash
npm install @browserbasehq/stagehand playwright
export OPENAI_API_KEY=sk-xxx
npx tsx run.ts        # 见同目录 stagehand_run.ts
```

---

## 17. Katana（URL 发现，ProjectDiscovery 出品）

**未执行原因**：Go 二进制，要从 GitHub Releases 下载；本环境的出口策略只放行 `raw.githubusercontent.com`，releases 的 CDN 不可达。

**算法**：给一个起始域名，并发递归爬遍站内链接，输出**全量 URL 清单**。可选 headless 模式解析 JS 里的链接。它只负责「这个站有哪些页面」，不负责「页面里有什么数据」。

**典型用法**：先用 Katana 摸清站点结构 → 再用 Scrapy/httpx 去抓你要的那几类页面。两步分开，比一个爬虫边发现边抓要清晰得多。

**对 13F**：不需要。SEC 的 URL 规则是公开且固定的（`.../YYYYqN_form13f.zip`），直接构造即可，没有任何需要「发现」的东西。

**怎么跑**
```bash
go install github.com/projectdiscovery/katana/cmd/katana@latest
katana -u https://example.com -d 2 -jc -o urls.txt
```

---

## 18. Docling（IBM 开源文档解析）

**未执行原因**：依赖 PyTorch + 多个视觉模型权重，安装体积数 GB，本容器磁盘配额不够。

**算法**：用版面分析模型识别页面区域（标题/正文/表格/图），再用专门的表格结构识别模型（TableFormer）还原单元格的行列关系，最后输出结构化 JSON 或 Markdown。

**和 PyMuPDF（方法 11）的区别**：
- PyMuPDF —— 按坐标和线条**推测**表格结构。快、轻，但遇到无线条表格、跨页表格、合并单元格就容易错
- Docling —— 用**模型**理解表格结构。准确率明显更高，尤其是财报这种复杂表格；代价是慢、重

**对 13F**：SEC 数据集是 TSV/XML，用不上。但如果要处理基金寄来的 PDF 季报，Docling 是目前表格识别最好的开源选择。

**怎么跑**
```bash
pip install docling          # 会拉 torch，几个 G，耐心等
```
```python
from docling.document_converter import DocumentConverter
res = DocumentConverter().convert("report.pdf")
print(res.document.export_to_markdown())
for t in res.document.tables:
    print(t.export_to_dataframe())
```
