# Demo Fund Management LP — Form 13F Holdings

Period: Q2 2026 · Filed: 2026-08-14 · CIK: 0001999999 ·
Total value: $299,250,000,000

| Rank | Ticker | Company | % Portfolio | Activity | Shares | Value ($) | Current Price | 52W High | 52W Low |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | AAPL | Apple Inc | 22.04 | Unchanged | 227917808 | 65950296000 |  |  |  |
| 2 | BRK.B | Berkshire Hathaway Inc | 13.11 | Add | 98400000 | 39240000000 |  |  |  |
| 3 | GOOGL | Alphabet Inc Class A | 10.52 | Buy | 142300000 | 31480000000 |  |  |  |
| 4 | MSFT | Microsoft Corp | 9.87 | Unchanged | 61200000 | 29540000000 |  |  |  |
| 5 | AMZN | Amazon.com Inc | 8.43 | Reduce | 111500000 | 25230000000 |  |  |  |
| 6 | NVDA | NVIDIA Corp | 7.15 | Add | 134800000 | 21400000000 |  |  |  |
| 7 | XOM | Exxon Mobil Corp | 5.62 | Unchanged | 142000000 | 16820000000 |  |  |  |
| 8 | JPM | JPMorgan Chase & Co | 4.98 | Buy | 61900000 | 14900000000 |  |  |  |
| 9 | KO | Coca-Cola Co | 3.74 | Unchanged | 400000000 | 11190000000 |  |  |  |
| 10 | PFE | Pfizer Inc | 2.31 | Sold Out | 0 | 0 |  |  |  |

**Fixture design note.** The first seven columns are real HTML in the page source —
any HTTP client plus an HTML parser can read them. The last three columns
(Current Price / 52W High / 52W Low) are injected by JavaScript
after load, exactly the way Dataroma renders its price columns. A static fetch returns them
empty; only a method that executes JavaScript will see values. That one difference is what
separates the tool categories in this lab.