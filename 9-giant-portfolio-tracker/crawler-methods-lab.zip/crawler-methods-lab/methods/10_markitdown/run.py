#!/usr/bin/env python3
"""
方法 10 — MarkItDown（任意格式 → Markdown）

算法：
  1. 按扩展名/MIME 派发到对应的转换器（HTML / PDF / DOCX / XLSX / PPTX / 图片 …）
  2. 每个转换器把内容归一化成 Markdown
  3. 表格转成 Markdown 表格语法，标题转成 #，列表转成 -

定位：它不是爬虫，是**格式归一化层**。
典型用法是放在管线中间 —— 爬虫负责把文件弄下来，MarkItDown 负责把
十几种格式统一成一种文本，再喂给下游（LLM、全文检索、diff 比对）。

对 13F 场景：SEC 的数据集是 TSV/XML，本来就是结构化的，
走 MarkItDown 等于把结构拆掉再拼回去，没有意义。
但如果你要处理的是**基金寄来的 PDF 季报**，它就很合适。
"""
import sys, os, time, re
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from markitdown import MarkItDown
from common import save

HERE = os.path.dirname(os.path.abspath(__file__))
FIXTURE = os.path.join(os.path.dirname(HERE), "..", "target", "fixture_13f.html")
COLS = ["rank", "ticker", "company", "pct", "activity", "shares", "value",
        "current_price", "w52_high", "w52_low"]


def main():
    t0 = time.time()
    md_engine = MarkItDown()
    res = md_engine.convert(os.path.abspath(FIXTURE))
    md = res.text_content

    # 从 Markdown 表格里把行解析回结构化数据
    rows = []
    for line in md.splitlines():
        line = line.strip()
        if not line.startswith("|"):
            continue
        cells = [c.strip() for c in line.strip("|").split("|")]
        if len(cells) < 7:
            continue
        if not re.fullmatch(r"\d+", cells[0]):      # 跳过表头和分隔行
            continue
        cells += [""] * (len(COLS) - len(cells))
        rows.append(dict(zip(COLS, cells)))

    out = os.path.join(HERE, "output")
    os.makedirs(out, exist_ok=True)
    with open(os.path.join(out, "page.md"), "w", encoding="utf-8") as f:
        f.write(md)

    save(HERE, rows, elapsed=time.time() - t0,
         extra={"markdown_chars": len(md), "also_wrote": "output/page.md"},
         notes="读本地文件而非发请求 —— 它是格式转换器不是爬虫；表格被转成 Markdown 表格后需再解析一次")


if __name__ == "__main__":
    main()
