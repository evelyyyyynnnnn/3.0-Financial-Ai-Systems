#!/usr/bin/env python3
"""
方法 02 — httpx + selectolax（静态页最快组合）

算法：
  1. httpx 发 GET —— 和 requests 同级的 API，但原生支持 HTTP/2 和 async
  2. selectolax 的 HTMLParser 解析 —— 底层是 C 写的 lexbor 引擎
  3. css() 选择器定位行，css_first() 取单元格

和方法 01 的唯一区别在解析器：BeautifulSoup 构造的是 Python 对象树，
selectolax 在 C 层完成解析，只在取值时过一次 Python。页面越大差距越明显，
实测通常快 5–10 倍。抓几万页时这个差距才值钱；抓十几页没必要换。
"""
import sys, os, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

import httpx
# selectolax 1.0 起 modest 后端被弃用，必须用 lexbor（更快，且遵循 HTML5 标准）
from selectolax.lexbor import LexborHTMLParser as HTMLParser
from common import TARGET_LOCAL, save

HERE = os.path.dirname(os.path.abspath(__file__))
COLS = ["rank", "ticker", "company", "pct", "activity", "shares", "value",
        "current_price", "w52_high", "w52_low"]


def main():
    t0 = time.time()
    with httpx.Client(timeout=20, follow_redirects=True) as c:
        r = c.get(TARGET_LOCAL)
        r.raise_for_status()
        html = r.text

    tree = HTMLParser(html)
    rows = []
    for tr in tree.css("#holdings tbody tr"):
        tds = [td.text(strip=True) for td in tr.css("td")]
        row = dict(zip(COLS, tds))
        row["cusip"] = tr.attributes.get("data-cusip", "")
        rows.append(row)

    save(HERE, rows, raw=html, raw_ext="html", elapsed=time.time() - t0,
         extra={"http_version": r.http_version},
         notes="与 01 结果完全一致，解析更快；同样看不到 JS 列")


if __name__ == "__main__":
    main()
