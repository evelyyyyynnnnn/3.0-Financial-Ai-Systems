#!/usr/bin/env python3
"""
方法 07 — Playwright（真实浏览器，执行 JavaScript）★ 分水岭

算法：
  1. 启动一个真实的 Chromium 进程（headless）
  2. page.goto() 加载页面 —— 浏览器会执行所有 JS、发起 XHR、渲染 DOM
  3. 等待渲染完成（这里等 body[data-hydrated] 属性出现）
  4. 从**渲染后的 DOM**里取数据

这是本实验里第一个能拿到 JS 注入列的方法。
前面 01–06 看到的都是服务器返回的原始 HTML，
Playwright 看到的是浏览器执行完脚本之后的最终 DOM。

代价：启动一个浏览器进程 ≈ 几百 MB 内存、几百毫秒到几秒。
比静态抓取慢一到两个数量级。所以原则是：
**能静态抓就别开浏览器；只在数据确实由 JS 产生时才用。**

怎么判断要不要用：curl 一下看看目标数据在不在原始 HTML 里，
在就用方法 02，不在才上 Playwright。
"""
import sys, os, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from playwright.sync_api import sync_playwright
from common import TARGET_LOCAL, save

HERE = os.path.dirname(os.path.abspath(__file__))
COLS = ["rank", "ticker", "company", "pct", "activity", "shares", "value",
        "current_price", "w52_high", "w52_low"]


def main():
    t0 = time.time()
    rows, rendered = [], ""
    with sync_playwright() as p:
        browser = p.chromium.launch(args=["--no-sandbox"])
        page = browser.new_page()
        page.goto(TARGET_LOCAL, wait_until="networkidle")
        page.wait_for_selector("body[data-hydrated='true']", timeout=10000)

        rows = page.eval_on_selector_all(
            "#holdings tbody tr",
            """els => els.map(tr => {
                const td = [...tr.children].map(c => c.textContent.trim());
                return {rank:td[0], ticker:td[1], company:td[2], pct:td[3],
                        activity:td[4], shares:td[5], value:td[6],
                        current_price:td[7], w52_high:td[8], w52_low:td[9],
                        cusip: tr.getAttribute('data-cusip') || ''};
            })"""
        )
        rendered = page.content()          # 渲染后的 DOM，不是原始 HTML
        page.screenshot(path=os.path.join(HERE, "output_screenshot.png"),
                        full_page=True)
        browser.close()

    save(HERE, rows, raw=rendered, raw_ext="html", elapsed=time.time() - t0,
         extra={"engine": "Chromium (headless)",
                "screenshot": "output_screenshot.png"},
         notes="★ 拿到了 JS 注入的三列；raw.html 是渲染后 DOM，对比 01 的 raw.html 可见差异")


if __name__ == "__main__":
    main()
