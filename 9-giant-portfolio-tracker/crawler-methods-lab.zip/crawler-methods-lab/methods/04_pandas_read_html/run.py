#!/usr/bin/env python3
"""
方法 04 — pandas.read_html（表格一行搞定）

算法：
  1. 取回 HTML
  2. pd.read_html() 自动找出页面里所有 <table>，每个转成一个 DataFrame

这是「页面主体就是一张规整表格」时最省事的办法 —— 一行代码，
自动处理表头、合并单元格、数值列。缺点是拿不到 <td> 以外的东西
（比如 data-cusip 这种属性），也无法按属性筛选。

你那个 13F 场景里，如果只要表格本体，这是性价比最高的一条。
"""
import sys, os, time, io
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

import requests
import pandas as pd
from common import TARGET_LOCAL, save

HERE = os.path.dirname(os.path.abspath(__file__))


def main():
    t0 = time.time()
    r = requests.get(TARGET_LOCAL, timeout=20)
    r.raise_for_status()

    tables = pd.read_html(io.StringIO(r.text))
    df = tables[0]
    df.columns = ["rank", "ticker", "company", "pct", "activity", "shares",
                  "value", "current_price", "w52_high", "w52_low"]
    df = df.fillna("")

    rows = [{k: ("" if v == "" else str(v)) for k, v in rec.items()}
            for rec in df.to_dict("records")]
    # pandas 会把整数读成 int，统一成字符串以便和其它方法对齐
    for row in rows:
        for k in ("rank", "shares", "value"):
            if row[k].endswith(".0"):
                row[k] = row[k][:-2]
        if row["pct"] and "." not in row["pct"]:
            row["pct"] = row["pct"] + ".0"

    out = os.path.join(HERE, "output")
    os.makedirs(out, exist_ok=True)
    df.to_csv(os.path.join(out, "holdings.csv"), index=False, encoding="utf-8-sig")

    save(HERE, rows, raw=r.text, raw_ext="html", elapsed=time.time() - t0,
         extra={"tables_found": len(tables), "also_wrote": "output/holdings.csv"},
         notes="一行解析整张表，自动识别表头；但拿不到 data-cusip 这类属性")


if __name__ == "__main__":
    main()
