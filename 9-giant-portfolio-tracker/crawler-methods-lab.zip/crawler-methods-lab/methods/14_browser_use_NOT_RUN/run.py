#!/usr/bin/env python3
"""
方法 14 — Browser Use（LLM 驱动浏览器）   ⚠ 本实验环境未执行

未执行原因：需要 LLM API key，每一步都产生真实 token 费用。
            本实验不替你花钱，也不在无人值守下让 agent 自由上网。

算法（和前面所有方法都不是一类东西）：
  1. 起一个真实浏览器，打开页面
  2. 把 DOM 里的**可交互元素**抽出来，编号成文本清单
     （[1] 搜索框 [2] 登录按钮 [3] 下一页链接 …）
  3. 把「清单 + 你的任务描述 + 历史动作」丢给大模型
  4. 模型回一个动作（点第 3 个、在第 1 个里输入 xxx、往下滚）
  5. 执行，重新抽 DOM，回到第 3 步，循环直到模型判断任务完成

它和 Playwright 的根本区别：
  Playwright —— **你**写死每一步该点哪里
  Browser Use —— **模型**每一步临场决定点哪里

所以它的适用场景是：**流程不固定、页面每次都不一样、不值得为它写 parser**。
比如「去这十个供应商后台各自导出上月账单」——每个后台长得都不一样。

对 13F 场景的判断：**明确不要用。**
  · SEC 是固定 URL 的静态文件，没有任何需要「临场判断」的地方
  · 每页过一次大模型 = 慢几百倍、贵几千倍
  · 结果不确定：同样的输入，模型两次可能走不同路径
  · 提示词注入风险：页面里可以藏给 agent 看的指令

什么时候真该用它：登录墙后面、多步表单、没有 API 又必须模拟人操作。
你那个 PERM 采集器就是典型的合适场景。

怎么跑：
    pip install browser-use
    playwright install chromium
    export OPENAI_API_KEY=sk-xxx        # 或 ANTHROPIC_API_KEY
    python3 run.py
"""
import os, sys, asyncio, json

HERE = os.path.dirname(os.path.abspath(__file__))
TASK = (
    "打开 http://127.0.0.1:8899/fixture_13f.html，"
    "把持仓表里每一行的 ticker、% Portfolio、Shares、Current Price 读出来，"
    "以 JSON 数组返回，不要编造任何数值。"
)


async def run():
    from browser_use import Agent
    from langchain_openai import ChatOpenAI       # 也可换成 ChatAnthropic

    agent = Agent(
        task=TASK,
        llm=ChatOpenAI(model="gpt-4o-mini"),
        max_failures=2,
    )
    history = await agent.run(max_steps=12)
    return history.final_result()


def main():
    if not (os.environ.get("OPENAI_API_KEY") or os.environ.get("ANTHROPIC_API_KEY")):
        print("未设置 LLM API key —— 跳过。这正是本方法标记为「未执行」的原因。")
        print("提醒：真要跑，先确认目标站点可信 —— agent 会读取页面内容并据此行动，"
              "恶意页面可以藏提示词注入。")
        return

    result = asyncio.run(run())
    out = os.path.join(HERE, "output")
    os.makedirs(out, exist_ok=True)
    with open(os.path.join(out, "result.json"), "w", encoding="utf-8") as f:
        json.dump({"task": TASK, "result": result}, f, ensure_ascii=False,
                  indent=2, default=str)
    print("已写出 output/result.json")


if __name__ == "__main__":
    main()
