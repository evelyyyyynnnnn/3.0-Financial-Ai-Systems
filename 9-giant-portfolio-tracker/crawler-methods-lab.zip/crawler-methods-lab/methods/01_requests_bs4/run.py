#!/usr/bin/env python3
"""
方法 01 — requests + BeautifulSoup（行业基线）

算法：
  1. requests.get() 发一个普通 HTTP GET，拿回 HTML 字节流
  2. BeautifulSoup 把字节流解析成 DOM 树（默认 html.parser，这里用更快的 lxml）
  3. 用 find/select 按标签和 class 定位 <tbody> 下的每个 <tr>
  4. 逐行按列序号取 <td> 的文本

本质：纯文本处理。不执行任何 JavaScript，看到的就是服务器返回的原始 HTML。
"""
import sys, os, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

import requests
from bs4 import BeautifulSoup
from common import TARGET_LOCAL, save

HERE = os.path.dirname(os.path.abspath(__file__))
COLS = ["rank", "ticker", "company", "pct", "activity", "shares", "value",
        "current_price", "w52_high", "w52_low"]


def main():
    t0 = time.time()
    r = requests.get(TARGET_LOCAL, timeout=20)
    r.raise_for_status()

    soup = BeautifulSoup(r.text, "lxml")
    rows = []
    for tr in soup.select("#holdings tbody tr"):
        tds = [td.get_text(strip=True) for td in tr.find_all("td")]
        row = dict(zip(COLS, tds))
        row["cusip"] = tr.get("data-cusip", "")
        rows.append(row)

    save(HERE, rows, raw=r.text, raw_ext="html", elapsed=time.time() - t0,
         notes="静态 HTML 全拿到；JS 注入的三列为空（预期行为）")


if __name__ == "__main__":
    main()
