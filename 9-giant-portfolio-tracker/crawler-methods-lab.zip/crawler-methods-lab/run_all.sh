#!/usr/bin/env bash
# 一键复现：起靶站 → 跑所有可执行方法 → 汇总对比表
#
#   bash run_all.sh
#
# 依赖安装见 requirements.txt。未执行的方法（13–18）需要外部 API key 或运行时，
# 不在此脚本内，各自目录的 run.py / README.md 里有完整说明。

set -u
cd "$(dirname "$0")"
export NO_PROXY='*' no_proxy='*'

PORT=8899
echo "▶ 启动本地靶站 (:$PORT)"
python3 target/serve.py $PORT >/tmp/lab_serve.log 2>&1 &
SERVER=$!
trap 'kill $SERVER 2>/dev/null' EXIT
sleep 2

if ! curl -sS --noproxy '*' -o /dev/null "http://127.0.0.1:$PORT/fixture_13f.html"; then
  echo "✗ 靶站起不来，退出"; exit 1
fi
echo "✓ 靶站就绪"
echo

for m in 01_requests_bs4 02_httpx_selectolax 03_lxml_xpath 04_pandas_read_html \
         05_scrapy 06_curl_cffi 07_playwright 08_crawl4ai 09_scrapling \
         10_markitdown 11_pymupdf ; do
  echo "▶ $m"
  timeout 300 python3 "methods/$m/run.py" >/dev/null 2>&1 \
    && echo "  ✓" || echo "  ✗ 失败（详见 methods/$m/output/）"
done

echo "▶ 12_cli_downloaders"
timeout 120 bash methods/12_cli_downloaders/run.sh >/dev/null 2>&1 \
  && echo "  ✓" || echo "  ✗"

echo
echo "▶ 汇总"
python3 collect_results.py
