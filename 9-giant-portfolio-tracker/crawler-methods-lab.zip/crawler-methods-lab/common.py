#!/usr/bin/env python3
"""各方法 demo 共用的小工具：统一的目标地址、结果落盘、自检。"""
import json
import os
import time

TARGET_LOCAL = os.environ.get("LAB_TARGET", "http://127.0.0.1:8899/fixture_13f.html")
# 真实远程目标（证明不只是本地自娱自乐）。raw.githubusercontent 在本实验环境可达。
TARGET_REMOTE = "https://raw.githubusercontent.com/python/cpython/main/README.rst"

STATIC_COLS = ["rank", "ticker", "company", "pct", "activity", "shares", "value"]
JS_COLS = ["current_price", "w52_high", "w52_low"]
EXPECTED_ROWS = 10
EXPECTED_FIRST = {"ticker": "AAPL", "pct": "22.04", "shares": "227917808"}


def save(method_dir, rows, raw=None, raw_ext="html", extra=None, elapsed=None, notes=""):
    """把一次抓取的结果落盘，并返回一份自检摘要。"""
    out = os.path.join(method_dir, "output")
    os.makedirs(out, exist_ok=True)

    with open(os.path.join(out, "rows.json"), "w", encoding="utf-8") as f:
        json.dump(rows, f, ensure_ascii=False, indent=2)

    if raw is not None:
        mode, enc = ("wb", None) if isinstance(raw, bytes) else ("w", "utf-8")
        with open(os.path.join(out, f"raw.{raw_ext}"), mode, encoding=enc) as f:
            f.write(raw)

    got_static = bool(rows) and all(
        str(rows[0].get(c, "")).strip() != "" for c in STATIC_COLS if c in rows[0]
    )
    first = rows[0] if rows else {}
    correct = all(str(first.get(k, "")).strip() == v for k, v in EXPECTED_FIRST.items()
                  if k in first)
    got_js = bool(rows) and any(
        str(r.get(c, "")).strip() not in ("", "None") for r in rows for c in JS_COLS
    )

    summary = {
        "method": os.path.basename(method_dir),
        "rows": len(rows),
        "rows_expected": EXPECTED_ROWS,
        "static_cols_ok": got_static,
        "first_row_correct": correct,
        "js_cols_captured": got_js,
        "elapsed_s": round(elapsed, 3) if elapsed is not None else None,
        "notes": notes,
        "ran_at": time.strftime("%Y-%m-%d %H:%M:%S"),
    }
    if extra:
        summary.update(extra)

    with open(os.path.join(out, "summary.json"), "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)

    print(json.dumps(summary, ensure_ascii=False))
    return summary
