#!/usr/bin/env python3
"""把各方法 output/summary.json 汇总成一张对比表（控制台 + CSV + JSON）。"""
import csv
import glob
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, "results")
os.makedirs(RES, exist_ok=True)

NOT_RUN = {
    "13_firecrawl": "需 FIRECRAWL_API_KEY，云端按量计费",
    "14_browser_use": "需 LLM API key，按 token 计费",
    "15_skyvern": "需 LLM key + Docker Compose 全栈",
    "16_stagehand": "Node/TypeScript 生态 + 需 LLM key",
    "17_katana": "Go 二进制，需从 GitHub Releases 下载（出口策略不放行）",
    "18_docling": "依赖 PyTorch + 模型权重，数 GB，磁盘配额不足",
}

rows = []
for p in sorted(glob.glob(os.path.join(HERE, "methods", "*", "output", "summary.json"))):
    try:
        with open(p, encoding="utf-8") as f:
            d = json.load(f)
    except Exception:
        continue
    name = d.get("method") or os.path.basename(os.path.dirname(os.path.dirname(p)))
    if name.startswith("12_cli"):                 # CLI 那个 summary 结构不同
        rows.append({"method": name, "status": "RUN", "rows": "—",
                     "static_ok": "—", "js_cols": "✗", "elapsed_s": "—",
                     "note": "纯下载器，不做解析"})
        continue
    rows.append({
        "method": name,
        "status": "RUN" if d.get("rows") else "FAIL",
        "rows": d.get("rows", 0),
        "static_ok": "✓" if d.get("static_cols_ok") else "✗",
        "js_cols": "✓" if d.get("js_cols_captured") else "✗",
        "elapsed_s": d.get("elapsed_s", ""),
        "note": (d.get("notes") or "")[:70],
    })

# CLI 下载器单独读
cli = os.path.join(HERE, "methods", "12_cli_downloaders", "output", "summary.json")
if os.path.exists(cli) and not any(r["method"].startswith("12") for r in rows):
    rows.append({"method": "12_cli_downloaders", "status": "RUN", "rows": "—",
                 "static_ok": "—", "js_cols": "✗", "elapsed_s": "—",
                 "note": "纯下载器，不做解析"})

for k, why in NOT_RUN.items():
    rows.append({"method": k, "status": "NOT_RUN", "rows": "—", "static_ok": "—",
                 "js_cols": "—", "elapsed_s": "—", "note": why})

rows.sort(key=lambda r: r["method"])

hdr = ["method", "status", "rows", "static_ok", "js_cols", "elapsed_s", "note"]
w = {h: max(len(h), *(len(str(r[h])) for r in rows)) for h in hdr}
line = "  ".join(h.ljust(w[h]) for h in hdr)
print(line)
print("-" * len(line))
for r in rows:
    print("  ".join(str(r[h]).ljust(w[h]) for h in hdr))

with open(os.path.join(RES, "comparison.csv"), "w", encoding="utf-8-sig", newline="") as f:
    cw = csv.DictWriter(f, fieldnames=hdr)
    cw.writeheader()
    cw.writerows(rows)
with open(os.path.join(RES, "comparison.json"), "w", encoding="utf-8") as f:
    json.dump(rows, f, ensure_ascii=False, indent=2)

ran = sum(1 for r in rows if r["status"] == "RUN")
js = sum(1 for r in rows if r["js_cols"] == "✓")
print(f"\n实跑 {ran} 种 · 未执行 {len(NOT_RUN)} 种 · 能拿到 JS 渲染列的 {js} 种")
print(f"已写出 results/comparison.csv 和 comparison.json")
